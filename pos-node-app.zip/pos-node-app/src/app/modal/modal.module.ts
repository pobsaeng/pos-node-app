// import { NgModule } from '@angular/core';
// import { CommonModule } from '@angular/common';
// import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
// import { CustomerComponent } from '../customer/customer.component';

// @NgModule({
//   imports: [
//     NgbModule.forRoot(),
//     CommonModule,
//     CustomerComponent
//   ],
//   exports: [CustomerComponent],
//   declarations: [CustomerComponent]
// })
// export class ModalModule { }
