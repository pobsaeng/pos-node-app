import { BrowserModule } from '@angular/platform-browser';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { AppComponent } from './app.component';

import { LoginService } from '../login/login.service';
import { AuthGuard } from './auth-guard.service';

import { ModalModule } from '../modal/modal.module';
import { LoginModule } from '../login/login.module';
import { CategoriesModule } from '../categories/categories.module';
import { AppRoutesModule } from './app-routes.module';

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    // NgbModule,
    BrowserModule,
    AppRoutesModule,
    LoginModule,
    CategoriesModule,
    // ModalModule
  ],
  exports: [RouterModule],
  providers: [
    AuthGuard,
    LoginService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
