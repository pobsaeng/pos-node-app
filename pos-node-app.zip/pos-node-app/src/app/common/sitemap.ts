export function siteMap() {
    return {
        login: {
            "LOGIN_URL": "http://10.100.72.109:8000/api/signin"
        },
        cateogires: {
            "Attribute1": "value4",
            "Attribute2": "value5",
            "Attribute3": "value6"
        }
    };
}
