export function siteMap() {
    return {
        login: {
            "LOGIN_URL": "http://172.20.10.3:8000/api/signin"
        },
        cateogires: {
            "Attribute1": "value4",
            "Attribute2": "value5",
            "Attribute3": "value6"
        }
    };
}