import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NgbModule, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';

import { CategoriesComponent } from './categories.component';
import { CategoriesRoutesModule } from './categories-routes.module';
import { ModalComponent } from '../modal/modal.component';

@NgModule({
  imports: [
    NgbModule.forRoot(), //modal
    CommonModule
  ],
  exports: [CategoriesRoutesModule],
  declarations: [
    CategoriesComponent,
    ModalComponent //modal component 
  ]
})
export class CategoriesModule { }
