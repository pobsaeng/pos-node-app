import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { GroupproductComponent } from './groupproduct.component';
import { AuthGuard } from '../auth/auth.guard';

const routes: Routes = [{ path: 'groupproduct', component: GroupproductComponent, canActivate: [AuthGuard] }];

@NgModule({
  imports: [RouterModule.forRoot(routes, { useHash: true })],
  exports: [RouterModule]
})
export class GroupproductRoutingModule { }
