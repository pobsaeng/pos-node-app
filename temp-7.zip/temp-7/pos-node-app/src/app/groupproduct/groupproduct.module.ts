import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { GroupproductRoutingModule } from './groupproduct-routing.module';
import { GroupproductComponent } from './groupproduct.component';
import { GroupproductService } from './groupproduct.service';
import { FixWordPipe } from '../common/FixWord.pipe';
import { DateTimeFormatPipe } from '../common/DateTimeFormat.pipe';

@NgModule({
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    CommonModule,
    GroupproductRoutingModule
  ],
  declarations: [
    GroupproductComponent,
    FixWordPipe
  ],
  providers: [
    GroupproductService,
    DateTimeFormatPipe
  ]
})
export class GroupproductModule { }
