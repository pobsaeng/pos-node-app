import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule }   from '@angular/forms';

import { ProductRoutingModule } from './product-routing.module';
import { AddproductComponent } from './addproduct.component';
import { FileuploadService } from './fileupload.service';

@NgModule({
  imports: [
    FormsModule,
    CommonModule,
    ProductRoutingModule
  ],
  declarations: [
    AddproductComponent
    ],
    providers: [
    FileuploadService
    ]
})
export class ProductModule { }
