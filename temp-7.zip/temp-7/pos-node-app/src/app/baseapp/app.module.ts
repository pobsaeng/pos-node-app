import { BrowserModule } from '@angular/platform-browser';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { AppComponent } from './app.component';

import { LoginModule } from '../login/login.module';
import { CategoriesModule } from '../categories/categories.module';
import { AppRoutesModule } from './app-routes.module';
// import { ProductModule } from '../product_/product.module';
import { ProductModule } from '../product/product.module';
import { GroupproductModule } from '../groupproduct/groupproduct.module';
import { ProfileModule } from '../profile/profile.module';

@NgModule({
  imports: [
    // NgbModule,
    BrowserModule,
    AppRoutesModule,
    LoginModule,
    CategoriesModule,
    ProductModule,
    GroupproductModule,
    ProfileModule
  ],
  exports: [RouterModule],
  declarations: [
    AppComponent
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
