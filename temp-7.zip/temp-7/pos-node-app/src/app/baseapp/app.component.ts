import { Component } from '@angular/core';
import { AuthService } from '../auth/auth.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  private showNavBar: boolean = false;

  constructor(private authService: AuthService) { }

  ngOnInit() {
    this.authService.showNavBarEmitter.subscribe(
      (bool: boolean) => {
        if (bool !== null) {
          this.showNavBar = bool;
        }
      }
    );
  }

  isAuth() {
    return this.authService.isAuthenticated();
  }

  onLogout() {
    this.authService.logout();
  }
}
