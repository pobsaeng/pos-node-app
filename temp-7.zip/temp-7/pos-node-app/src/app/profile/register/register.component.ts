import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormControl, FormBuilder, Validators, FormGroup } from '@angular/forms';
import { RegisterService } from './register.service';
import { DateTimeFormatPipe } from '../../common/DateTimeFormat.pipe';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  userModel: any = {};
  registerForm: FormGroup;
  isValidFormSubmitted = null;

  ngOnInit() { }

  constructor(
    private router: Router,
    private registerService: RegisterService,
    private dateTimeFormat: DateTimeFormatPipe,
    private formBuilder: FormBuilder) {

    this.registerForm = this.formBuilder.group({
      firstname: [null, [Validators.required]],
      lastname: [null, [Validators.required]],
      username: [null, [Validators.required]],
      password: [null, [Validators.required]],
      passwordconfirm: [null, [Validators.required]]
    });
  }

  get firstname() {
    return this.registerForm.get('firstname');
  }
  get lastname() {
    return this.registerForm.get('lastname');
  }
  get username() {
    return this.registerForm.get('username');
  }
  get password() {
    return this.registerForm.get('password');
  }
  get passwordconfirm() {
    return this.registerForm.get('passwordconfirm');
  }

  onRegisterFormSubmit() {
    this.isValidFormSubmitted = false;
    if (this.registerForm.invalid) {
      return;
    }
    this.isValidFormSubmitted = true;

    this.userModel = this.registerForm.value;
    this.userModel['user_id'] = null;
    this.userModel['role_id'] = 0;
    this.userModel['token_no'] = null;
    let currdatetime = this.dateTimeFormat.transform(new Date());
    this.userModel['create_date'] = currdatetime;
    this.userModel['last_update'] = currdatetime;
    delete this.userModel['passwordconfirm'];
    
    this.registerService.create(this.userModel, function (result) {
      console.log(result);
    });
  }

}
