import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LoginComponent } from './login.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { AuthGuard } from '../auth/auth.guard';
import { ToastComponent } from '../shared/toast/toast.component';
import { LoginRoutesModule } from './login-routes.module';
import { AuthService } from '../auth/auth.service';

@NgModule({
  imports: [
    HttpModule,
    FormsModule,
    ReactiveFormsModule,
    CommonModule,
    LoginRoutesModule, //routing module

  ],
  providers: [
    AuthService,
    ToastComponent,
    AuthGuard
  ],
  exports: [LoginRoutesModule],
  declarations: [
    LoginComponent,
    ToastComponent
  ] //login component
})
export class LoginModule { }
