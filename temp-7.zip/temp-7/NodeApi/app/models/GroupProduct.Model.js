const db = require('../database/MySQL');

class GroupProductModel {
    constructor() {
        this.connection = db.createConnection();
    }
    create(params, callback) {
        let parameters = [];
        //set string SQL
        let question = '';
        let sql = 'INSERT INTO tb_group_product (';
        let fields = Object.keys(params);
        for (let i = 0; i < fields.length; i++) {
            sql += fields[i] + ',';
            question += '?,';
        }
        sql = sql.substring(0, sql.length - 1);
        question = question.substring(0, question.length - 1);

        sql += ") VALUES(" + question + ")";

        //add parameters
        for (let key in params) {
            parameters.push(params[key]);
        }

        this.connection.query(sql, parameters, function (err, result) {
            if (err) throw err;
            callback(result);
        });
    }
    update(params, callback) {
        // var sql = `UPDATE tb_group_product set ? WHERE group_product_id = ?`;
        // var params = {
        //     group_product_code: 'AU',
        //     group_product_name: 'อาหารกระป๋อง',
        //     group_product_detail: 'ขายแพ็คและขายชิ้น',
        //     group_product_created_date: new Date(),
        //     group_product_last_update: new Date()
        // };
        // this.connection.query(`${sql}`, [params, id], function (err, result) {
        //     if (err) throw err;
        //     callback(result);
        // });

        var sql = `UPDATE tb_group_product set ? WHERE group_product_id = ?`;
        var arrParams = {
            group_product_code: params.group_product_code,
            group_product_name: params.group_product_name,
            group_product_detail: params.group_product_detail,
            group_product_created_date: params.group_product_created_date,
            group_product_last_update: params.group_product_last_update
        };

        this.connection.query(`${sql}`, [arrParams, params.group_product_id], function (err, result) {
            if (err) throw err;
            callback(result);
        });
    }
    delete(id, callback) {
        var sql = `DELETE FROM tb_group_product WHERE group_product_id = ?`;
        this.connection.query(`${sql}`, [id], function (err, result) {
            if (err) console.log("Error deleting : %s ", err);
            callback(result);
        });
    }
    findAll(callback) {
        this.connection.query("select * from tb_group_product", function (err, rows) {
            if (err) {
                callback({
                    success: false,
                    exception: 'Query error: ' + err
                });

            } else if (rows.length > 0) {
                callback({
                    success: true,
                    rows: rows
                });

            } else {
                callback({
                    success: false
                });
            }
        });
    }
    findById(id, callback) {
        this.connection.query("select * from tb_group_product where group_product_id = ?", id, function (err, rows) {
            if (err) {
                callback({
                    success: false,
                    exception: 'Query error: ' + err
                });

            } else if (rows.length > 0) {
                callback({
                    success: true,
                    rows: rows
                });

            } else {
                callback({
                    success: false
                });
            }
        });
    }

    findByLike(value, callback) {
        this.connection.query("select * from tb_group_product where group_product_name LIKE ?",
            '%' + value + '%',
            function (err, rows) {
                if (err) {
                    callback({
                        success: false,
                        exception: 'Query error: ' + err
                    });
                } else if (rows.length > 0) {
                    callback({
                        success: true,
                        rows: rows
                    });

                } else {
                    callback({
                        success: false
                    });
                }
            });
    }
}
module.exports = GroupProductModel;
