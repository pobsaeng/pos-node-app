const db = require('../database/MySQL');
const PromQueries = require('../database/PromQueries');
const uidGenerator = require('node-unique-id-generator');

class RegisterModel {
    constructor() {
        this.connection = db.createConnection();
        this.promQueries = new PromQueries(this.connection);
    }
    create(params, callback) {
        let uid = uidGenerator.generateUniqueId();

        let parameters = [];
        //set string SQL
        let question = '';
        let sql = 'INSERT INTO tbl_user (';
        let fields = Object.keys(params);
        for (let i = 0; i < fields.length; i++) {
            sql += fields[i] + ',';
            question += '?,';
        }
        sql = sql.substring(0, sql.length - 1);
        question = question.substring(0, question.length - 1);

        sql += ") VALUES(" + question + ")";

        //add parameters
        for (let key in params) {
            if (key === 'token_no') {
                parameters.push(uid);

            } else {
                parameters.push(params[key]);
            }
        }
        console.log(parameters);

        this.connection.query(sql, parameters, function (err, result) {
            if (err) throw err;
            callback(result);
        });
    }
    edit(params, callback) {

    }
    remove(id, callback) {

    }

}
module.exports = RegisterModel;
