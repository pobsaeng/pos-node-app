const UserModel = require("../models/Product.Model");
const Paging = require("../common/Paging");
const Utilities = require("../common/Utilities");

class ProductController {
    constructor() {
        this.userModel = new UserModel();
        this.paging = new Paging();
        this.util = new Utilities();
    }
    verifyToken(token, callback) {
        let me = this;
        if (typeof token != 'undefined' && token != null) {
            me.util.jwtVerify(token, 'secret_key', function (decoded) {
                console.log(decoded);

                if (decoded != null) {
                    callback(true);
                } else {
                    callback(false);
                }
            });
        }
    }
    getAllProduct(req, res) {
        let me = this;
        const headers = req.headers["authorization"];
        me.verifyToken(headers, function (status) {
            if (status) {
                me.userModel.findAll(function (result) {
                    if (result != null) {
                        res.send({ success: true, data: result });
                    }
                });

            } else {
                res.send({ success: false, exception: 'token invalid!' });
            }
        });


    }
    getPaging(req, res) {
        let me = this;

        me.userModel.findLimit(0, 5, function (result) {
            let pager = me.paging.getPager(result.total, 1, 10);
            pager.data = result.rows;
            res.send(pager);
        });

        // let pager = this.paging.getPager(250, 1, 10);
        // res.send(pager);
        // let startIndex = pager.startIndex;
        // let endIndex = pager.endIndex + 1;
        // console.log(startIndex, endIndex);
    }
}
module.exports = ProductController;