const RegisterModel = require("../models/Register.Model");

class RegisterController {
    constructor() {
        this.registerModel = new RegisterModel();
    }
    insert(req, res) {
        this.registerModel.create(req.body, function (result) {
            res.send(result);
        });
    }
}
module.exports = RegisterController;
