const ProductsModel = require("../models/Products.Model");

class ProductsController {
    constructor() {
        this.productsModel = new ProductsModel();
    }
    insert(req, res) {
        this.productsModel.create(function (result) {
            res.send(result);
        });
    }
}
module.exports = ProductsController;