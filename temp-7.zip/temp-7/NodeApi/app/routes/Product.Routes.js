'use strict';
const BookModel = require("../models/Book.Model");
const ProductModel = require("../models/Product.Model");
const ProductController = require("../controllers/Product.Controller");

class ProductRoutes {
    constructor(app) {
        this.app = app;

        this.productController = new ProductController();
        this.bookModel = new BookModel();
        this.productModel = new ProductModel();
    }
    appRoutes() {
        let me = this;
        let arr_product = [null, 'Node.JS', '11220', '20123', 500, 500, 690, '1'];

        this.app.get('/api/product', (request, response) => {
            this.productController.getAllProduct(request, response);
        });
        this.app.get('/api/paging', (request, response) => {
            this.productController.getPaging(request, response);
        });
        this.app.post('/api/insert/', (request, response) => {
            me.productModel.insert(arr_product, function (status) {
                response.send(status);
            });
        });

        this.app.get('/api/verifyToken', (request, response) => {
            this.productController.verifyToken(request, response, 
                "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJqd3RUb2tlbiI6Ijk5MTIwMSIsImlhdCI6MTUxNTEyNzQ4OX0.yY-vu2kBMw1RGtYNfUuBpEC44kiK5umcV6NY0TYF7R0");
        });
        
        this.app.delete('/api/products/:id', (request, response) => {

        });

        this.app.put('/api/products/:id', (request, response) => {

        });
    }

    getRoutes() {
        this.appRoutes();
    }
}
module.exports = ProductRoutes;
