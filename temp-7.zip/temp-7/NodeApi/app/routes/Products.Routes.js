const ProductsController = require("../controllers/Products.Controller");

class ProductsRoutes {
    constructor(app) {
        this.app = app;
        this.productsController = new ProductsController();
    }
    getRoutes() {
        this.app.get('/api/addproduct', (request, response) => {
            this.productsController.insert(request, response);
        });
    }
}
module.exports = ProductsRoutes;