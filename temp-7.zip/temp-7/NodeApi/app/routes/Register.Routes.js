const RegisterController = require('../controllers/Register.Controller');

class RegisterRoutes {
    constructor(app) {
        this.app = app;
        this.registerController = new RegisterController();
    }
    getRoutes() {
        this.app.post('/api/register/create', (request, response) => {
            this.registerController.insert(request, response);
        });
    }
}
module.exports = RegisterRoutes;
