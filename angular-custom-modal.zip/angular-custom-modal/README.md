# angular2-custom-modal

Angular 2 Custom Modal

To see a demo and further details go to http://jasonwatmore.com/post/2017/01/24/angular-2-custom-modal-window-dialog-box