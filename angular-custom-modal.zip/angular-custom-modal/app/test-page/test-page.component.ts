﻿import { Component } from '@angular/core';

@Component({
    moduleId: module.id.toString(),
    templateUrl: 'test-page.component.html'
})

export class TestPageComponent {
}